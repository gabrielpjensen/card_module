//
//  GJPGLX.h
//  GJPGLX
//
//  Created by Gabriel Jensen on 9/8/17.
//  Copyright © 2017 XMode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GJPGLX/GJPGLXAPI.h>

//! Project version number for GJPGLX.
FOUNDATION_EXPORT double GJPGLXVersionNumber;

//! Project version string for GJPGLX.
FOUNDATION_EXPORT const unsigned char GJPGLXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GJPGLX/PublicHeader.h>


